# =============================================================================
# SEO Content — R2 Content Write Policy (ADR-066)
# =============================================================================
#
# Rôle : autorise / refuse les écritures sur le contenu d'une page R2_PRODUCT
# (URL `/pieces/:gamme/:marque/:modele/:type.html`).
#
# Consommé par (futur, PR 1 monorepo) :
#   - backend/src/modules/seo/r2/gates/r2-opa-evaluator.service.ts (WASM
#     bundle embedded, sync eval < 1ms)
#   - backend/src/modules/seo/r2/gates/r2-governance-gate.service.ts
#     (delegate de la décision invariant à cette policy avant write-gate)
#
# Discipline canon (MEMORY feedback_opa_rego_invariants_only) :
#   Cette policy enforce des INVARIANTS uniquement. Aucun scoring, aucun
#   weight, aucune logique métier. Les seuils (THRESHOLD_V1=45, weights
#   0.35/0.35/0.20/0.10) restent en TS testable, fournis en input.
#
# Source de vérité scoring : backend/src/modules/seo/r2/constants/
#   r2-eligibility.constants.ts (TS, property-based fast-check)
#
# Verdict empirique qui motive le verrou : feedback expert 2026-05-15 sur
# plan R2 v2 — 10 points correctifs + 7 améliorations self-review. Le vrai
# risque est l'explosion de cardinalité SEO inutile (1.6 TDI 105 vs 110,
# même OEM set, même catalogue). Eligibility + SUPPRESSED canonical
# préviennent l'index bloat.
#
# Plan source : /home/deploy/.claude/plans/le-contenu-de-r2-scalable-tower.md
# ADR : ADR-066-r2-content-composition-v2.md
# =============================================================================

package seo.content.r2.write

import data.seo.content.r2.write.allow
import data.seo.content.r2.write.deny

import rego.v1

# ── Décision par défaut : DENY (fail-closed) ─────────────────────────────────

# ── Règles d'autorisation ─────────────────────────────────────────────────────

# Règle 1 : human_curated (NON-SUPPRESSED)
# Écriture humaine explicite admin-ui (IsAdminGuard authentifié). Toujours
# autorisée pour decisions ≠ suppressed. Pour `suppressed`, la Règle 4
# (human_curated_suppressed) impose les invariants canonical (anti-chain).
# Cf ADR-067 2026-05-15 : SUPPRESSED même humain doit avoir canonical valide.

# Règle 2 : human_validated_llm
# Écriture LLM validée explicitement par humain via review queue
# (POST /api/admin/seo/r2/review-queue/:id/approve flip de source au moment
# de l'approbation). L'actor est obligatoire pour audit-trail.

# Règle 3 : pipeline_generated_index
# Génération automatisée par le pipeline R2 v2, décision INDEX. Requiert :
#   - feature flag R2_V2_ENABLED ON (improvement D, kill-switch sans redeploy)
#   - flag_state pipeline enabled
#   - aucun lock actif (un humain a verrouillé → pas d'overwrite)
#   - decision="index" ET content_hash présent (no INDEX sans contenu)
#   - eligibility_score dans [0, 100]
#   - retry_count ≤ 2
#   - ADR-070 (2026-05-16) prerequisites INDEX strict (R5+R6+R7 doctrine) :
#       - R8 snapshot CADRE : r8_snapshot_status ∈ {minimal, enriched, stale}
#       - R1 gamme context CADRE : r1_gamme_context_status == "loaded"
#       - MATIÈRE FACTUELLE : knowledge_facts_count > 0 OR validated_wiki_evidence_count > 0
#       - H1 disambiguation active : h1_contains_motor_power_pattern == true
#       - S_VARIANT_DISAMBIGUATION section présente
#       - Pas de specs brutes en paragraphes longs (R7 technical criteria = evidence only)

# ADR-070 strict gates INDEX

# ADR-070 helpers (Round 5+6+7 strict INDEX prerequisites)

adr070_r8_cadre_ok(obj) if {
	valid_r8_snapshot_statuses[obj.r8_snapshot_status]
}

adr070_r1_cadre_ok(obj) if {
	obj.r1_gamme_context_status == "loaded"
}

# MATIÈRE FACTUELLE : KG facts > 0 OR WIKI evidence > 0 (au moins un)
adr070_factual_matter_ok(obj) if {
	is_number(obj.knowledge_facts_count)
	obj.knowledge_facts_count > 0
}

adr070_factual_matter_ok(obj) if {
	is_number(obj.validated_wiki_evidence_count)
	obj.validated_wiki_evidence_count > 0
}

adr070_disambiguation_ok(obj) if {
	obj.h1_contains_motor_power_pattern == true
	obj.s_variant_disambiguation_present == true
}

adr070_no_raw_specs_in_editorial(obj) if {
	obj.body_long_form_section_contains_raw_specs == false
}

# valid R8 snapshot statuses (canon ADR-070 §G, status enum strict Round 2)
valid_r8_snapshot_statuses := {"minimal", "enriched", "stale"}

# Règle 4 : human_curated_suppressed (manual override, ADR-067 amendment 2026-05-15)
#
# ADR-067 INTERDIT pipeline_generated → suppressed. Seul un admin humain peut
# manuellement flipper une page vers SUPPRESSED (doublon connu confirmé, page
# legacy abandonnée). Anti-canonical-chain invariants restent valables.
#
# Requiert :
#   - source_kind = "human_curated"
#   - actor non-vide (audit-trail)
#   - canonical_target_type_id non-null
#   - canonical_target.decision = "index" (no chain)
#   - canonical_target.pg_id = self.pg_id (no cross-gamme)

# Règle 5 : pipeline_generated_review_or_regenerate
# Décisions intermédiaires (REVIEW_REQUIRED, REGENERATE) qui écrivent un draft
# avec status approprié. Pas de contenu publié, mais persistance pour audit
# trail et queue handling. Pas de canonical_target requis.

# Règle 6 : pipeline_generated_reject
# Décision REJECT — écrit la raison dans __seo_r2_qa_reviews, no content.
# ADR-068 2026-05-16 : reject_reason DOIT être l'une des 4 raisons UNIQUES
# (productCount_under_2, data_invalid, url_impossible, compatibility_absent).
# Pas REJECT pour similarité (→ REVIEW_REQUIRED).

is_valid_reject_reason(r) if {
	allowed := {"productCount_under_2", "data_invalid", "url_impossible", "compatibility_absent"}
	allowed[r]
}

# ── Helpers (predicats utilitaires) ──────────────────────────────────────────

is_non_empty_string(s) if {
	is_string(s)
	count(s) > 0
}

is_valid_eligibility_score(score) if {
	is_number(score)
	score >= 0
	score <= 100
}

is_valid_retry_count(n) if {
	is_number(n)
	n >= 0
	n <= 2
}

is_valid_canonical_target(obj) if {
	is_number(obj.canonical_target_type_id)
	obj.canonical_target.decision == "index"
	obj.canonical_target.pg_id == obj.pg_id
}

# Détecte la présence de signaux commerciaux dans une section
# qui n'est pas S_REASSURANCE (zone confinée par design).
contains_commercial_signal_outside_reassurance(section_key, content) if {
	section_key != "S_REASSURANCE"
	commercial_signals := {"prix", "promo", "stock", "panier", "livraison", "ajouter au panier"}
	some signal in commercial_signals
	contains(lower(content), signal)
}

# ── Raisons de refus (introspectable côté NestJS) ────────────────────────────
#
# Les règles deny[reason] permettent au gateway de logger précisément
# pourquoi une écriture a été refusée (insert dans __seo_r2_qa_reviews).

# ADR-067 amendment 2026-05-15 : pipeline_generated → suppressed est INTERDIT.
# Seul un admin humain (source_kind=human_curated) peut flipper vers SUPPRESSED.

# ── ADR-068 amendment 2026-05-16 : 4 actions auto INTERDITES sur page valide ──

# Une page valide = productCount >= 2 ET compatibilité réelle.
# Si la page est valide, le pipeline NE PEUT PAS auto-noindex / canonicaliser / exclure sitemap.

# DENY 1 : pipeline → noindex_follow sur page valide (désindexation auto interdite)

# DENY 2 : REJECT scope strict — 4 raisons UNIQUEMENT
# (productCount<2, data_invalid, url_impossible, compatibility_absent)
valid_reject_reasons := {
	"productCount_under_2",
	"data_invalid",
	"url_impossible",
	"compatibility_absent",
}

# DENY 3 : Page valide INDEX/REVIEW_REQUIRED ne peut pas émettre canonical sibling
# (canonicalisation auto vers sœur interdite par ADR-068)
# ── ADR-070 amendment 2026-05-16 : R8+R1 first canon + INTERNAL DIFFERENCE EXHAUSTION + Technical criteria = evidence ──
#
# Formule canon Round 5 : R2Content = render(R8VehicleSnapshot, R1GammeContext, VehiclePartKnowledgeFacts, ValidatedWikiEvidence)
#   CADRE   = R8 + R1 (sans = générique, JAMAIS INDEX)
#   MATIÈRE = KG facts + WIKI evidence (sans = pauvre, JAMAIS INDEX)
#
# Round 6 : INTERNAL DIFFERENCE EXHAUSTION (L0-L3 avant L4 external)
# Round 7 : Technical criteria = evidence only (PAS éditorial — paragraphes spec dumps interdits)
#
# 5 deny invariants stricts INDEX (pipeline only) :
# DENY ADR-070 #1 : R8 snapshot CADRE requis pour INDEX
# (valid_r8_snapshot_statuses set defined near allow rule 3, canon Round 2 status enum strict)
# DENY ADR-070 #2 : R1 gamme context CADRE requis pour INDEX
# DENY ADR-070 #3 : MATIÈRE FACTUELLE (KG facts OU WIKI validée) requise pour INDEX
# R8 + R1 seuls = CADRE générique sans valeur SEO. Au moins 1 fact KG ou 1 evidence WIKI validée requis.
# DENY ADR-070 #4 : H1 + S_VARIANT_DISAMBIGUATION obligatoires pour INDEX
# Disambiguation active : H1 doit contenir power+body+years pattern, et la section S_VARIANT_DISAMBIGUATION doit exister.
# DENY ADR-070 #5 : Technical criteria = evidence only (Round 7)
# Paragraphes longs avec specs brutes répétées (>5× pattern \d+[,.]\d+\s?mm) dans une section éditoriale = INTERDIT.
# Les critères techniques DOIVENT rester dans S_COMPAT_DIFFERENCES / S_TECHNICAL_TABLE_COMPACT / S_SELECTION_WARNING uniquement.
# Forbidden commercial signal in non-reassurance section
# Catch-all : source_kind non reconnue → deny par défaut
