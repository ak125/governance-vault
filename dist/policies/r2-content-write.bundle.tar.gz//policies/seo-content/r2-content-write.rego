# =============================================================================
# SEO Content — R2 Content Write Policy (ADR-066)
# =============================================================================
#
# Rôle : autorise / refuse les écritures sur le contenu d'une page R2_PRODUCT
# (URL `/pieces/:gamme/:marque/:modele/:type.html`).
#
# Consommé par (futur, PR 1 monorepo) :
#   - backend/src/modules/seo/r2/gates/r2-opa-evaluator.service.ts (WASM
#     bundle embedded, sync eval < 1ms)
#   - backend/src/modules/seo/r2/gates/r2-governance-gate.service.ts
#     (delegate de la décision invariant à cette policy avant write-gate)
#
# Discipline canon (MEMORY feedback_opa_rego_invariants_only) :
#   Cette policy enforce des INVARIANTS uniquement. Aucun scoring, aucun
#   weight, aucune logique métier. Les seuils (THRESHOLD_V1=45, weights
#   0.35/0.35/0.20/0.10) restent en TS testable, fournis en input.
#
# Source de vérité scoring : backend/src/modules/seo/r2/constants/
#   r2-eligibility.constants.ts (TS, property-based fast-check)
#
# Verdict empirique qui motive le verrou : feedback expert 2026-05-15 sur
# plan R2 v2 — 10 points correctifs + 7 améliorations self-review. Le vrai
# risque est l'explosion de cardinalité SEO inutile (1.6 TDI 105 vs 110,
# même OEM set, même catalogue). Eligibility + SUPPRESSED canonical
# préviennent l'index bloat.
#
# Plan source : /home/deploy/.claude/plans/le-contenu-de-r2-scalable-tower.md
# ADR : ADR-066-r2-content-composition-v2.md
# =============================================================================

package seo.content.r2.write

import data.seo.content.r2.write.allow
import data.seo.content.r2.write.deny

import rego.v1

# ── Décision par défaut : DENY (fail-closed) ─────────────────────────────────

# ── Règles d'autorisation ─────────────────────────────────────────────────────

# Règle 1 : human_curated
# Écriture humaine explicite admin-ui (IsAdminGuard authentifié). Toujours
# autorisée, surpasse les locks et le feature flag (humain = autorité finale).

# Règle 2 : human_validated_llm
# Écriture LLM validée explicitement par humain via review queue
# (POST /api/admin/seo/r2/review-queue/:id/approve flip de source au moment
# de l'approbation). L'actor est obligatoire pour audit-trail.

# Règle 3 : pipeline_generated_index
# Génération automatisée par le pipeline R2 v2, décision INDEX. Requiert :
#   - feature flag R2_V2_ENABLED ON (improvement D, kill-switch sans redeploy)
#   - flag_state pipeline enabled
#   - aucun lock actif (un humain a verrouillé → pas d'overwrite)
#   - decision="index" ET content_hash présent (no INDEX sans contenu)
#   - eligibility_score dans [0, 100]
#   - retry_count ≤ 2

# Règle 4 : pipeline_generated_suppressed
# Génération automatisée, décision SUPPRESSED. Requiert tous les invariants
# canonical (improvement A, anti-chain prevention) :
#   - canonical_target_type_id non-null
#   - canonical_target.decision = "index" (no chain : SUPPRESSED → SUPPRESSED interdit)
#   - canonical_target.pg_id = self.pg_id (no cross-gamme canonical)
#   - feature flag + flag_state + scores valides comme règle 3

# Règle 5 : pipeline_generated_review_or_regenerate
# Décisions intermédiaires (REVIEW_REQUIRED, REGENERATE) qui écrivent un draft
# avec status approprié. Pas de contenu publié, mais persistance pour audit
# trail et queue handling. Pas de canonical_target requis.

# Règle 6 : pipeline_generated_reject
# Décision REJECT — écrit la raison dans __seo_r2_qa_reviews, no content.
# Pas de canonical target requis (le cas "pas de sibling fiable").

# ── Helpers (predicats utilitaires) ──────────────────────────────────────────

is_non_empty_string(s) if {
	is_string(s)
	count(s) > 0
}

is_valid_eligibility_score(score) if {
	is_number(score)
	score >= 0
	score <= 100
}

is_valid_retry_count(n) if {
	is_number(n)
	n >= 0
	n <= 2
}

is_valid_canonical_target(obj) if {
	is_number(obj.canonical_target_type_id)
	obj.canonical_target.decision == "index"
	obj.canonical_target.pg_id == obj.pg_id
}

# Détecte la présence de signaux commerciaux dans une section
# qui n'est pas S_REASSURANCE (zone confinée par design).
contains_commercial_signal_outside_reassurance(section_key, content) if {
	section_key != "S_REASSURANCE"
	commercial_signals := {"prix", "promo", "stock", "panier", "livraison", "ajouter au panier"}
	some signal in commercial_signals
	contains(lower(content), signal)
}

# ── Raisons de refus (introspectable côté NestJS) ────────────────────────────
#
# Les règles deny[reason] permettent au gateway de logger précisément
# pourquoi une écriture a été refusée (insert dans __seo_r2_qa_reviews).
# Forbidden commercial signal in non-reassurance section
# Catch-all : source_kind non reconnue → deny par défaut
