# =============================================================================
# SEO Content — R2 Runtime Read Policy (ADR-072)
# =============================================================================
#
# Rôle : enforcer les invariants CQRS read-side + DDD bounded contexts + 5
# prerequisites full-scale launch pour le pipeline R2 v2.
#
# Consommé par (futur, PR 2D monorepo) :
#   - backend/src/modules/seo/r2/gates/r2-runtime-read-evaluator.service.ts
#     (WASM bundle embedded, sync eval < 1ms)
#   - frontend/app/routes/pieces.$gamme.$marque.$modele.$type[.]html.tsx
#     (validation runtime read query au server-load time, dev mode debug)
#   - backend/src/modules/seo/admin/r2-full-scale-launch-gate.controller.ts
#     (validation 5 prerequisites avant flip feature flag V2 full-scale)
#
# Discipline canon (MEMORY feedback_opa_rego_invariants_only) :
#   Cette policy enforce des INVARIANTS architecturaux uniquement.
#   Aucun scoring, aucun weight, aucune logique métier.
#
# Source de vérité paradigme : ADR-072-r2-cqrs-ddd-snapshot-artifact.md
# Source plan : /home/deploy/.claude/plans/le-contenu-de-r2-scalable-tower.md
# =============================================================================

package seo.runtime.r2.read

import data.seo.runtime.r2.read.allow
import data.seo.runtime.r2.read.audit
import data.seo.runtime.r2.read.deny

import rego.v1

# ── Décision par défaut : ALLOW (fail-open pour runtime read non-destructif) ─
# Le runtime read est read-only par construction. Les deny ciblent des
# violations CQRS/DDD spécifiques. fail-open évite de bloquer toute requête
# Remix runtime si l'input policy a un champ inattendu.

# ── Tables/paths autorisés runtime read (CQRS read-side scope strict) ────────
#
# Le runtime Remix ne peut lire QUE :
#   - __seo_r2_pages (index parent + current_snapshot_id pointer)
#   - __seo_r2_page_snapshot (published artifact immutable)
#
# Toute lecture d'une autre table SEO R2 au request time = violation CQRS.
# Note : caches Redis (ex: r2:snapshot:{pgId}:{typeId}) sont OK car ce sont
# des dérivés du snapshot, pas une SoT alternative.

allowed_runtime_tables := {
	"__seo_r2_pages",
	"__seo_r2_page_snapshot",
}

# ── Bounded contexts owners (ADR-072 §2 DDD) ─────────────────────────────────
#
# Mapping aggregate_type → owner_module. Toute écriture cross-context doit
# passer par integration events (outbox), pas par accès direct SoT.

bounded_context_owners := {
	"R8VehicleSnapshot": "modules/seo/r8",
	"R1GammeContext": "modules/seo/r1",
	"VehiclePartKnowledgeFact": "modules/seo/r2/services/kg",
	"ValidatedWikiEvidence": "modules/seo/r2/services/research",
	"R2PageSnapshot": "modules/seo/r2/services/render",
}

# ── 5 Prerequisites full-scale launch (ADR-070 Round 6 canon) ────────────────
#
# Tous les 5 doivent être true avant flip feature flag R2_V2_FULL_SCALE.

full_scale_prerequisites := {
	"golden_examples_validated",
	"business_signature_validated",
	"internal_difference_score_calibrated",
	"r1_completeness_audited",
	"r8_snapshot_stability_verified",
}

# ── DENY 1 : CQRS runtime read scope strict ──────────────────────────────────
#
# Runtime ne peut lire QUE __seo_r2_pages + __seo_r2_page_snapshot.
# Toute lecture d'une autre table SEO R2 au request time = bug CQRS.

# ── DENY 2 : No live compose au request time ─────────────────────────────────
#
# Aucun appel R2CompositionService / R2DataLoaderService / R2KnowledgeGraphService
# au request time. Compose = batch async background uniquement.

# ── DENY 3 : DDD bounded context isolation ───────────────────────────────────
#
# Un module ne peut JAMAIS écrire dans la SoT d'un autre bounded context.
# Communication cross-context = integration events via __seo_outbox_event.

# ── DENY 4 : 5 prerequisites full-scale launch mandatory ─────────────────────
#
# Avant flip R2_V2_FULL_SCALE feature flag, tous les 5 prerequisites doivent
# être validés (canon ADR-070 Round 6).

# Helper : true if input.prerequisites_status[name] == true
prerequisite_satisfied(name, obj) if {
	obj.prerequisites_status[name] == true
}

# ── Audit reasons (toujours émises pour observabilité) ───────────────────────
# Surface info reason même si allow=true, pour logging traces OTel.
